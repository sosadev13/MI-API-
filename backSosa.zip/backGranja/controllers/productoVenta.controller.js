import ProductoVenta from "../models/productoVenta.models.js";
import mongoose from "mongoose";

// Obtener todos los productos
export const getAllProductos = async (req, res) => {
  try {
    const productos = await ProductoVenta.find({}, { __v: 0 });
    if (productos.length === 0) {
      return res.status(404).json({ msg: "No se encontraron productos" });
    }
    return res.status(200).json({ productos });
  } catch (error) {
    return res.status(500).json({ msg: "Error al obtener los productos" });
  }
};

// Obtener producto por ID
export const getProductoById = async (req, res) => {
  const id = req.params.id;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ msg: "ID no válido" });
    }

    const producto = await ProductoVenta.findById(id);
    if (!producto) {
      return res.status(404).json({ msg: "Producto no encontrado" });
    }
    return res.status(200).json({ producto });
  } catch (error) {
    return res.status(500).json({ msg: "Error al obtener el producto" });
  }
};

// Buscar productos por nombre parcial
export const getProductosByNombre = async (req, res) => {
  const { nombre } = req.params;
  try {
    if (!nombre || typeof nombre !== "string") {
      return res.status(400).json({ msg: "Nombre no válido" });
    }

    const productos = await ProductoVenta.find({
      nombre: { $regex: nombre, $options: "i" }, // Búsqueda insensible a mayúsculas
    });

    if (productos.length === 0) {
      return res
        .status(404)
        .json({ msg: "No se encontraron productos con ese nombre" });
    }
    return res.status(200).json({ productos });
  } catch (error) {
    return res.status(500).json({ msg: "Error al obtener los productos" });
  }
};

// Crear un nuevo producto
export const postProducto = async (req, res) => {
  const { nombre, precio, disponibilidad, descripcion } = req.body;
  const nuevoProducto = new ProductoVenta({
    nombre,
    precio,
    disponibilidad,
    descripcion,
  });

  try {
    const validationError = nuevoProducto.validateSync();
    if (validationError) {
      const errorMessages = Object.values(validationError.errors).map(
        (error) => error.message
      );
      return res.status(400).json({ errors: errorMessages });
    }

    await nuevoProducto.save();
    return res.status(201).json({
      msg: "Producto guardado correctamente",
      producto: nuevoProducto,
    });
  } catch (error) {
    return res.status(500).json({ msg: "Error al guardar el producto" });
  }
};

// Actualizar un producto por ID
export const putProducto = async (req, res) => {
  const id = req.params.id;
  const body = req.body;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ msg: "ID no válido" });
    }

    const producto = await ProductoVenta.findByIdAndUpdate(id, body, {
      new: true,
      runValidators: true,
    });

    if (!producto) {
      return res
        .status(404)
        .json({ msg: "Producto no encontrado o actualizado" });
    }
    return res.status(200).json({
      msg: "Producto actualizado correctamente",
      producto,
    });
  } catch (error) {
    return res.status(500).json({ msg: "Error al actualizar el producto" });
  }
};

// Eliminar un producto por ID
export const deleteProducto = async (req, res) => {
  const id = req.params.id;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ msg: "ID no válido" });
    }

    const producto = await ProductoVenta.findByIdAndDelete(id);
    if (!producto) {
      return res
        .status(404)
        .json({ msg: "Producto no encontrado o eliminado" });
    }
    return res.status(200).json({
      msg: "Producto eliminado correctamente",
      producto,
    });
  } catch (error) {
    return res.status(500).json({ msg: "Error al eliminar el producto" });
  }
};
