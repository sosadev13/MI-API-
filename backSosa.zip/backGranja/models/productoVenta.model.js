import mongoose from "mongoose";

const productoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, "El nombre es obligatorio"], // Obligatorio con mensaje personalizado
    trim: true, // Elimina espacios innecesarios
  },
  precio: {
    type: Number,
    required: [true, "El precio es obligatorio"], // Obligatorio con mensaje personalizado
    min: [0, "El precio no puede ser negativo"], // Validación de mínimo
  },
  disponibilidad: {
    type: String,
    enum: ["Disponible", "Agotado", "Próximamente"], // Valores permitidos
    default: "Disponible", // Valor predeterminado
  },
  descripcion: {
    type: String,
    maxlength: [500, "La descripción no puede superar los 500 caracteres"], // Longitud máxima
  },
});

const Producto = mongoose.model("Producto", productoSchema);

export default Producto;
