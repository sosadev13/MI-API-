import productoVenta from "./productoVenta.routes.js";
import { Router } from "express";

const indexRoutes = Router();

indexRoutes.use("/productos", productoVenta);

export default indexRoutes;
