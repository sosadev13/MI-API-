import { Router } from "express";
import {
  getAllProductos,
  getProductoById,
  getProductosByNombre,
  postProducto,
  putProducto,
  deleteProducto,
} from "../controllers/productoVenta.controller.js"; // Ajusta la ruta según sea necesario

const productoVenta = Router();

// Rutas para productos
productoVenta.get("/", getAllProductos); // Obtener todos los productos

productoVenta.get("/:id", getProductoById); // Obtener producto por ID

productoVenta.get("/nombre/:nombre", getProductosByNombre); // Buscar productos por nombre parcial

productoVenta.post("/", postProducto); // Crear un nuevo producto

productoVenta.put("/:id", putProducto); // Actualizar un producto por ID

productoVenta.delete("/:id", deleteProducto); // Eliminar un producto por ID

export default productoVenta;
